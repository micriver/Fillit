/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sudoku_ult_solve.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mirivera <mirivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/09/30 17:18:40 by mrivera           #+#    #+#             */
/*   Updated: 2018/11/04 16:03:11 by mirivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		valid_number(char **sudoku, int num, int row, int col)
{
	int x;
	int y;
	int pos_x;
	int pos_y;

	pos_x = 0;
	pos_y = 0;
	x = 0;
	y = 0;
	while (x < 9)
	{
		if (sudoku[row][x++] == num)
			return (0);
	}
	while (y < 9)
	{
		if (sudoku[y++][col] == num)
			return (0);
	}
	x = (row / 3) * 3;
	y = (col / 3) * 3;
	while (pos_x < 3)
	{
		while (pos_y < 3)
		{
			if (sudoku[x + pos_x++][y + pos_y++] == num)
				return (0);
		}
	}
	return (1);
}

int		sudoku_ult_solve(char **sudoku, int row, int col)
{
	int num;

	num = 1;
	if (col >= 9)
	{
		row++;
		col = 0;
	}
	if (row >= 9)
		return (1);
	if (sudoku[row][col] == 0)
	{
		while (num <= 9)
		{
			if (valid_number(sudoku, num, row, col))
			{
				sudoku[row][col] = num;
				if (sudoku_ult_solve(sudoku, row, col + 1))
					return (1);
			}
			num++;
		}
		sudoku[row][col] = 0;
		return (0);
	}
	else
		return (sudoku_ult_solve(sudoku, row, col + 1));
}
