/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mirivera <mirivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/04 14:02:18 by mirivera          #+#    #+#             */
/*   Updated: 2018/11/04 15:52:16 by mirivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <unistd.h>

int		sudoku_ult_solve(char **sudoku, int row, int col);

int		ft_putchar(char c)
{
	write(1, &c, 1);
	return (0);
}

void	ft_putstr(char *str)
{
	while (*str != '\0')
	{
		ft_putchar(*str);
		str++;
	}
}

char	**sudoku_parse(int argc, char **argv)
{
	char 	**sudoku;
	int		i;
	int 	j;

	i = 1;
	sudoku = malloc(sizeof(char *) * 9);
	while (i < argc)
	{
		sudoku[i - 1] = malloc(sizeof(char) * 9);
		j = 0;
		while (j < 9)
		{
			if (argv[i][j] == '.')
				sudoku[i - 1][j] = 0;
			else
				sudoku[i - 1][j] = argv[i][j] - '0';
			j++;
		}
		i++;
	}
	return (sudoku);
}

void	sudoku_print(char **sudoku)
{
	int x;
	int y;

	y = 0;
	while (y < 9)
	{
		x = 0;
		while (x < 9)
		{
			ft_putchar('0' + sudoku[y][x]);
			x++;
			if (x % 9 != 0)
				ft_putchar(' ');
		}
		y++;
		ft_putchar('\n');
	}
}

void		sudoku_destroy(char **sudoku)
{
	int i;
	
	i = 1;
	while (i < 9)
	{
		free(sudoku[i++]);
	}
	free(sudoku);
}

int		main(int argc, char **argv)
{
	char **sudoku;
	
	sudoku = sudoku_parse(argc, argv);
	if (sudoku_ult_solve(sudoku, 0, 0) == 0)
		ft_putstr("Error\n");
	else
		sudoku_print(sudoku);
	sudoku_destroy(sudoku);
	return (0);
}
